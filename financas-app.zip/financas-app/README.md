# Finanças App

App de controle financeiro pessoal (despesas, renda, categorias e metas de guardar/investir), feito em React + Vite + Tailwind CSS.

Os dados ficam salvos no navegador do usuário (`localStorage`), então cada pessoa que acessar o site terá seus próprios dados salvos localmente ali.

## Rodar localmente

```bash
npm install
npm run dev
```

Abra o endereço que aparecer no terminal (geralmente `http://localhost:5173`).

## Publicar no Vercel

### Opção 1 — pelo site da Vercel (sem usar terminal)

1. Crie uma conta em https://vercel.com (pode entrar com GitHub, GitLab ou e-mail).
2. Suba esta pasta para um repositório no GitHub (pode arrastar os arquivos direto pela interface do GitHub em "Add file → Upload files", ou usar o GitHub Desktop).
3. No Vercel, clique em **Add New → Project**, selecione o repositório.
4. O Vercel detecta automaticamente que é um projeto Vite. Não precisa mudar nada — apenas clique em **Deploy**.
5. Em 1–2 minutos você recebe uma URL pública tipo `seu-projeto.vercel.app`.

### Opção 2 — pelo terminal (mais rápido se você já tem Node instalado)

```bash
npm install -g vercel
cd financas-app
vercel
```

Siga as perguntas (login, nome do projeto) e confirme. Ele te dá o link em seguida.
Para atualizar depois de mudar algo, rode `vercel --prod`.

## Estrutura do projeto

- `src/App.jsx` — todo o app (telas de despesas, renda, categorias, guardar/investir)
- `src/main.jsx` — ponto de entrada do React
- `src/index.css` — Tailwind + fontes
- `index.html` — HTML base
- `vite.config.js`, `tailwind.config.js`, `postcss.config.js` — configuração de build
